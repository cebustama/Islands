# Islands Documentation Governance Migration Roadmap — First Pass

Date: 2026-03-23  
Status: First-pass governance diagnosis and migration roadmap  
Scope: Islands package documentation governance migration  
Method basis: v0.4 governance stack + DSSW salvage workflow

---

## 1. Purpose

This document captures the **first-pass migration roadmap** for restructuring the Islands documentation into a governed documentation system.

This is **not** the final documentation set.
This is the roadmap that defines:

- what the package tier is,
- where current truth is currently hidden or mixed,
- what the target documentation spine should be,
- which subsystem authorities are warranted now,
- how to migrate folder-by-folder,
- which current files should be promoted, split, moved, archived, or verified,
- and what the next migration batches should be.

The roadmap is intentionally conservative.
It prioritizes **clarity, preservation, authority repair, and safe replacement** over aggressive cleanup.

---

## 2. Core diagnosis

The main documentation problem in Islands is **not lack of documentation**.
The problem is **authority ambiguity**.

The package currently presents a public-facing documentation surface centered on:

- overview
- noise
- mesh
- surfaces
- shaders
- graphs

But the actual package tree and runtime surface show a much more substantial **PCG subsystem**, including:

- runtime map pipeline code,
- deterministic data structures,
- base terrain generation,
- tests,
- golden/hash-based verification,
- and planning-heavy docs that currently carry real implementation truth.

This creates several governance risks:

1. **WIP acting as hidden law**
2. **legacy “SSoT” names still implying authority**
3. **roadmaps carrying implementation truth**
4. **reference docs competing with active truth**
5. **historical snapshots sitting too close to live subsystem understanding**
6. **unclear separation between active package runtime and legacy map-generation work**

---

## 3. Tier evaluation

### Recommended migration tier: **Tier L**

The migration should be treated as **Tier L**, even if the final maintained system could end up feeling closer to a disciplined Tier M.

### Why Tier L is appropriate now

- Multiple real subsystems exist: Noise, Meshes, Surfaces, Shaders, Graphs, PCG.
- The package has a heavy historically accumulated documentation load.
- `Documentation~/wip/` includes files with authority-signaling names such as `SSoT`, `Roadmap`, `Planning Report`, and `Snapshot`.
- A large amount of knowledge appears mixed across docs that combine implementation truth, planning, roadmap, history, and experimentation.
- There is significant risk of accidental false promotion if the migration is not performed conservatively.
- The package requires a **parallel replacement strategy**, not an in-place casual cleanup.

### Implication of Tier L treatment

The migration should use:

- explicit authority mapping,
- DSSW-based salvage,
- supersession tracking,
- migration logging,
- curated archive handling,
- and staged promotion of subsystem SSoTs.

---

## 4. Strategic migration goals

The migrated system must make it obvious:

- where current implemented truth lives,
- where roadmap intent lives,
- where current operational focus lives,
- where semantic changes are logged,
- where authority ownership is looked up,
- which docs are reference only,
- which docs are research only,
- which docs are historical only,
- which subsystems are official but not yet promoted to local SSoT authority,
- and what docs must be updated when technical changes occur.

---

## 5. Current documentary diagnosis

### 5.1 Package root role

The package root currently behaves like a **public entry surface**, mainly through `README.md`.
That role should remain.
But it should stop acting as the only map of the package’s documentation truth.

### 5.2 Current `Documentation~/` role

`Documentation~/` currently contains a mix of:

- package/module reference,
- subsystem explanations,
- snapshots,
- WIP truth,
- roadmap material,
- archive material,
- ideas,
- and progress reports.

This is precisely the kind of mixed surface that requires governance migration.

### 5.3 High-risk current authority zones

The highest-risk zone is:

- `Documentation~/wip/`

Especially files such as:

- `Islands_PCG_Pipeline_SSoT_v0_1_16.md`
- `Islands_PCG_Layout_Strategies_SSoT_v0_1_2.md`
- `Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
- `PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
- `Map Layers/Map_Generation_SSoT_v0.1.2_2026-01-29.md`
- `Map Layers/Islands_PCG_MapPipelineByLayers_Roadmap_v0.1.0_2026-01-29.md`

These names strongly imply authority, but under v0.4 governance they cannot be trusted automatically.
They must be re-evaluated by actual role and runtime evidence.

---

## 6. Authority diagnosis

### 6.1 False-authority docs

The following docs are authority-risk docs because their names imply more authority than they have safely earned under the current governance model:

- `Islands_PCG_Pipeline_SSoT_v0_1_16.md`
- `Islands_PCG_Layout_Strategies_SSoT_v0_1_2.md`
- `Map_Generation_SSoT_v0.1.2_2026-01-29.md`
- `PCG_Pipeline_Technical_Snapshot.md`
- `GraphLibrary_Pipeline_Technical_Doc.md`

### 6.2 WIP acting as truth

The migration must explicitly assume that **important current truth is living in WIP**.
That is not acceptable as a final governance state.

### 6.3 Reference docs at risk of becoming hidden law

These docs are useful but should be reclassified as **reference/module support**, not as primary authority by default:

- `overview.md`
- `noise.md`
- `mesh.md`
- `surfaces.md`
- `shaders.md`
- `graphs.md`

### 6.4 Roadmap carrying implementation truth

The integrated PCG roadmaps and progress reports appear to describe actual implementation milestones and state.
That is useful, but they should no longer function as the primary home of implemented truth.

### 6.5 Runtime verification requirements

At least the following areas require runtime-aware verification before final documentary promotion is locked:

- PCG core pipeline
- Map pipeline by layers
- Layout strategies
- GraphLibrary
- Noise subsystem (for clean promotion)

---

## 7. Target governance spine

## Recommended decision

Keep the governed documentation root inside **`Documentation~/`**.

Do **not** create a parallel `Docs/` root for this package.
For a Unity package, `Documentation~/` is the natural governed home.

### Target root structure

```text
Documentation~/
  README.md
  SSoT_INDEX.md
  SSoT_CONTRACTS.md
  coverage-matrix.md
  changelog-ssot.md
  CURRENT_STATE.md
  migration-log.md
  supersession-map.md

  systems/
  reference/
  planning/
    active/
    archive/
  research/
  archive/
  integrations/           (optional)
  governance/             (optional local governance reminder)
```

### Role of the main root docs

#### `Documentation~/README.md`
Navigation entrypoint for the governed docs root.

#### `Documentation~/SSoT_INDEX.md`
Explicit map of what currently counts as authority.

#### `Documentation~/SSoT_CONTRACTS.md`
Cross-cutting rules, boundaries, determinism semantics, validation expectations, and package-level contracts.

#### `Documentation~/coverage-matrix.md`
Lookup table from concept → primary doc owner.

#### `Documentation~/changelog-ssot.md`
Semantic changes, authority changes, and promotions/demotions.

#### `Documentation~/CURRENT_STATE.md`
Operational present tense: what is active, what is implemented, what is next.

#### `Documentation~/migration-log.md`
DSSW migration log.

#### `Documentation~/supersession-map.md`
Explicit map of old docs → new homes.

---

## 8. Subsystem authority evaluation

### 8.1 Noise

- **Current maturity:** high
- **Likely documentary role:** subsystem SSoT + reference
- **Promotion now:** yes, with minimal runtime verification batch
- **Target outcome:**
  - `systems/noise-ssot.md`
  - `reference/noise.md`

### 8.2 Meshes

- **Current maturity:** high
- **Likely documentary role:** subsystem SSoT + reference
- **Promotion now:** yes
- **Target outcome:**
  - `systems/meshes-ssot.md`
  - `reference/mesh.md`

### 8.3 Surfaces

- **Current maturity:** medium to high
- **Likely documentary role:** small subsystem SSoT or support doc under runtime systems
- **Promotion now:** yes, but keep it small and tightly scoped
- **Target outcome:**
  - `systems/surfaces-ssot.md` (small)
  - `reference/surfaces.md`

### 8.4 Graphs

- **Current maturity:** medium, with legacy/debt signals
- **Likely documentary role:** reference + support
- **Promotion now:** no
- **Reason:** runtime verification and cleanup needed before promoted local authority is justified
- **Target outcome:**
  - `reference/graphs.md`
  - possibly future `systems/graphs-ssot.md`

### 8.5 PCG core pipeline

- **Current maturity:** high
- **Likely documentary role:** promoted subsystem SSoT
- **Promotion now:** yes
- **Target outcome:**
  - `systems/pcg-core-ssot.md`

### 8.6 PCG layout strategies

- **Current maturity:** medium to high, but documentation is mixed
- **Likely documentary role:** staged subsystem support or future SSoT
- **Promotion now:** not yet as its own SSoT
- **Target outcome:**
  - staged under PCG
  - revisit after dedicated verification batch

### 8.7 Map pipeline by layers

- **Current maturity:** real, but only partially implemented
- **Likely documentary role:** promoted subsystem SSoT limited to implemented slice + active roadmap for the rest
- **Promotion now:** yes, but only for the implemented slice
- **Target outcome:**
  - `systems/map-pipeline-by-layers-ssot.md`
  - `planning/active/PCG_Roadmap.md`

### 8.8 Legacy tilemap map generation

- **Current maturity:** historically useful, not active authority by default
- **Likely documentary role:** legacy reference or archive
- **Promotion now:** no
- **Target outcome:**
  - `reference/legacy-tilemap-map-generation.md` or archive equivalent

### 8.9 Shader layer

- **Current maturity:** useful but not yet demanding a standalone SSoT in the first pass
- **Likely documentary role:** reference/integration
- **Promotion now:** no

### 8.10 Samples/demo layer

- **Current maturity:** sample context only
- **Likely documentary role:** demos and examples
- **Promotion now:** never as primary authority

---

## 9. Folder-by-folder migration roadmap

### 9.1 Package root docs

**Current role**  
Public entrypoint and package metadata surface.

**Target role**  
Public entrypoint only.

**Keep**  
- `README.md`
- `package.json`
- `make-tree-unity.bat`

**Actions**  
- Rewrite `README.md` so it points clearly to `Documentation~/README.md`.
- Keep root concise and package-facing.

**Risks**  
If rewritten too aggressively, package onboarding becomes worse.

---

### 9.2 `Documentation~/`

**Current role**  
Mixed docs root.

**Target role**  
Governed documentation root.

**Actions**  
- Add governance spine docs.
- Re-home current docs into systems/reference/planning/research/archive.
- Stop using root-level mixed files as implicit authority.

**Must not be lost**  
The current package/module explanations.

---

### 9.3 `Documentation~/subsystems/`

**Current role**  
Catch-all subsystem technical docs.

**Target role**  
No longer a category in itself.

**Actions**  
- Split docs by real role.
- Move snapshot-like material to `archive/` or `reference/`.
- Do not auto-promote these docs just because the folder says “subsystems”.

---

### 9.4 `Documentation~/wip/`

**Current role**  
Mixed WIP with hidden authority.

**Target role**  
No active truth should remain here.

**Actions**  
- Salvage using DSSW.
- Move planning to `planning/active/` or `planning/archive/`.
- Move support/reference to `reference/`.
- Move historical remnants to `archive/`.
- Promote only verified subsystem truth into `systems/`.

**Risks**  
Aggressive migration here is the biggest risk of losing deltas or recreating false authority.

---

### 9.5 `Documentation~/wip/archive/`

**Current role**  
Historical dump / preserved older states.

**Target role**  
Curated archive.

**Actions**  
- Keep historically useful items.
- Do not migrate entire redundant files if already absorbed elsewhere.
- Record supersession explicitly.

---

### 9.6 `Documentation~/wip/ideas/`

**Current role**  
Idea/research area.

**Target role**  
`research/ideas/`

**Actions**  
- Reclassify as research.
- Remove any implication of implementation authority.

---

### 9.7 `Documentation~/wip/Map Layers/`

**Current role**  
Mixed active roadmap + legacy authority-like map-generation docs.

**Target role**  
Split between:
- `planning/active/`
- `reference/legacy/`
- or `archive/legacy/`

**Actions**  
- Separate active map-pipeline-by-layers planning from legacy tilemap map generation.
- Do not let both continue to compete as if they describe the same active subsystem.

---

### 9.8 `Documentation~/wip/progress reports/`

**Current role**  
Operational reports / milestone snapshots.

**Target role**  
Planning archive support.

**Actions**  
- Move to `planning/archive/progress/`.
- Extract meaningful deltas into `CURRENT_STATE.md`, roadmap, and changelog if still relevant.

---

### 9.9 `Runtime/`

**Current role**  
Package code.

**Target role**  
Package code.

**Actions**  
- No governance spine here.
- Keep documentation ownership in `Documentation~/`.

---

### 9.10 `Runtime/Noise/`

**Target documentary role**  
Authoritative runtime backing for `systems/noise-ssot.md`.

**Actions**  
- Verify representative files.
- Create clean SSoT.

---

### 9.11 `Runtime/Meshes/`

**Target documentary role**  
Authoritative runtime backing for `systems/meshes-ssot.md`.

**Actions**  
- Promote based on current runtime evidence.

---

### 9.12 `Runtime/PCG/`

**Target documentary role**  
Primary subsystem authority backing for PCG docs.

**Actions**  
- Make this the first major subsystem rescued from WIP.
- Create clear docs for core PCG + map pipeline.

---

### 9.13 `Runtime/Graphs/`

**Current issue**  
There are signs of technical markdown living too close to runtime code.

**Target role**  
Code only.

**Actions**  
- Remove doc authority from runtime tree.
- Move explanatory docs into governed docs root.

---

### 9.14 `Editor/`

**Current role**  
Editor tooling.

**Target role**  
Code only, unless a real editor contract later justifies documentation.

---

### 9.15 `Samples~/`

**Current role**  
Demo/sample surface.

**Target role**  
Sample/demo context only.

**Actions**  
- Add local README if needed.
- Make it explicit that samples are not package authority.

---

## 10. First missing governance docs to draft

### 10.1 `Documentation~/README.md`
Should contain:

- purpose of the docs root,
- how this differs from root `README.md`,
- what to read first,
- how to navigate by authority,
- warning that reference/research/archive are not active truth.

### 10.2 `Documentation~/SSoT_INDEX.md`
Should contain:

- active authorities,
- subsystem status,
- navigation map,
- short local update loop,
- links to roadmap, current state, changelog, coverage matrix.

### 10.3 `Documentation~/SSoT_CONTRACTS.md`
Should contain:

- determinism expectations,
- stable stage execution ordering,
- hash/golden verification expectations,
- core package boundaries,
- distinction between active package runtime and legacy material,
- any cross-cutting runtime contracts that multiple systems rely on.

### 10.4 `Documentation~/coverage-matrix.md`
Should contain:

- concept owner mapping,
- primary home lookup,
- staged-vs-promoted subsystem status,
- cross-links to authority docs.

### 10.5 `Documentation~/changelog-ssot.md`
Should contain:

- semantic changes,
- authority promotions/demotions,
- splits/absorptions,
- notable contract changes.

### 10.6 `Documentation~/CURRENT_STATE.md`
Should contain:

- what is active now,
- what is implemented now,
- what the next migration focus is,
- what roadmap is active,
- what batch is next.

### 10.7 `Documentation~/migration-log.md`
Should contain:

- DSSW-oriented migration decisions,
- per-document salvage notes,
- rationale for archive vs absorb vs promote.

### 10.8 `Documentation~/supersession-map.md`
Should contain:

- old doc name,
- new home,
- superseded-by / absorbed-into / archived-as decision,
- status.

---

## 11. Local update-loop integration

The package-local system should include the local update loop in two places:

1. **Short version in `SSoT_INDEX.md`**
2. **Full package-local operational reminder in `Documentation~/governance/`**

### Required operational loop

1. Identify what concept changed.
2. Find its primary home in `coverage-matrix.md`.
3. Update that primary home first.
4. Then update, if needed:
   - `CURRENT_STATE.md` if operational focus changed
   - `changelog-ssot.md` if meaning / authority / contract changed
   - `coverage-matrix.md` only if ownership changed
   - `SSoT_INDEX.md` if structure/navigation changed
   - folder `README.md` files only if folder semantics changed

---

## 12. File-by-file migration map

## Package root

### `README.md`
- **Action:** keep in place, rewrite
- **Target role:** public package entrypoint
- **Status framing:** Active

### `package.json`
- **Action:** keep in place
- **Target role:** package metadata
- **Status framing:** Active

### `make-tree-unity.bat`
- **Action:** keep in place
- **Target role:** tooling helper
- **Status framing:** ActiveSupport

## Current `Documentation~/` surface

### `overview.md`
- **Action:** absorb into new docs navigation and/or package reference
- **Target role:** reference / navigation support
- **Status framing:** PlannedSubsystemSupport

### `noise.md`
- **Action:** move to `reference/noise.md`
- **Target role:** reference
- **Status framing:** ActiveSupport

### `mesh.md`
- **Action:** move to `reference/mesh.md`
- **Target role:** reference
- **Status framing:** ActiveSupport

### `surfaces.md`
- **Action:** move to `reference/surfaces.md`
- **Target role:** reference
- **Status framing:** ActiveSupport

### `shaders.md`
- **Action:** move to `reference/shaders.md`
- **Target role:** reference
- **Status framing:** ActiveSupport

### `graphs.md`
- **Action:** move to `reference/graphs.md`
- **Target role:** reference
- **Status framing:** PlannedSubsystemSupport

## `Documentation~/subsystems/`

### `GraphLibrary_Pipeline_Technical_Doc.md`
- **Action:** absorb into reference + archive original
- **Target role:** reference/historical support
- **Status framing:** HistoricalSupport

### `PCG_Pipeline_Technical_Snapshot.md`
- **Action:** move to archive or historical reference
- **Target role:** historical snapshot
- **Status framing:** HistoricalOnly

## `Documentation~/wip/`

### `Islands_PCG_Pipeline_SSoT_v0_1_16.md`
- **Action:** split + absorb
- **Target role:**
  - `systems/pcg-core-ssot.md`
  - `systems/map-pipeline-by-layers-ssot.md`
  - `SSoT_CONTRACTS.md`
- **Status framing:** Active source material, not final authority

### `Islands_PCG_Layout_Strategies_SSoT_v0_1_2.md`
- **Action:** stage, verify, do not auto-promote
- **Target role:** planned subsystem support or future SSoT
- **Status framing:** PlannedSubsystemSupport

### `Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
- **Action:** absorb into `planning/active/PCG_Roadmap.md`
- **Target role:** active roadmap
- **Status framing:** Active source material

### `PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
- **Action:** absorb deltas into roadmap; archive report
- **Target role:** historical planning support
- **Status framing:** HistoricalSupport

### `Rehydration_Prompt_PhaseF_F3_NoiseJobs_Topology_2026-02-03.md`
- **Action:** move to archive or process/reference
- **Target role:** process artifact
- **Status framing:** HistoricalOnly

## `Documentation~/wip/Map Layers/`

### `Map_Generation_SSoT_v0.1.2_2026-01-29.md`
- **Action:** move to legacy reference or archive
- **Target role:** legacy map-generation reference
- **Status framing:** HistoricalOnly unless runtime evidence says otherwise

### `Islands_PCG_MapPipelineByLayers_Roadmap_v0.1.0_2026-01-29.md`
- **Action:** absorb into `planning/active/PCG_Roadmap.md`
- **Target role:** active roadmap source
- **Status framing:** Active source material

## `Documentation~/wip/progress reports/`

### `Islands_PCG_PhaseF_Progress_Report_F0_F2.md`
- **Action:** move to planning archive; extract deltas
- **Target role:** historical progress report
- **Status framing:** HistoricalSupport

## `Documentation~/wip/archive/`

### All historical reports, old roadmaps, technical bibles
- **Action:** curate and preserve selectively
- **Target role:** archive
- **Status framing:** HistoricalOnly

---

## 13. Cross-reference and supersession repair

### Immediate repairs needed

- Root `README.md` must point to the governed docs root.
- Old WIP files with `SSoT` in the name must stop implying active authority once replacements exist.
- Historical snapshot docs must receive explicit superseded-by or historical-only headers.
- Runtime-local markdown should not continue to function as active documentary authority.

### Docs that should receive supersession handling early

- `Islands_PCG_Pipeline_SSoT_v0_1_16.md`
- `Map_Generation_SSoT_v0.1.2_2026-01-29.md`
- `Islands_PCG_MapPipelineByLayers_Roadmap_v0.1.0_2026-01-29.md`
- `Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
- `PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
- `PCG_Pipeline_Technical_Snapshot.md`
- `GraphLibrary_Pipeline_Technical_Doc.md`

---

## 14. Safe replacement guide

### Step 1 — Freeze current docs as input corpus
Do not start by mass renaming or deleting.
Treat the current documentation tree as migration input.

### Step 2 — Create the new governed structure in parallel
Create the new spine inside `Documentation~/` without removing the old material yet.

### Step 3 — Migrate by authority, not by filename prestige
Do not assume `SSoT`, `Technical Bible`, `Roadmap`, or `Snapshot` labels are trustworthy.
Use DSSW salvage and runtime evidence.

### Step 4 — Promote only what has earned promotion
Promote:
- PCG core
- implemented map pipeline slice
- meshes
- noise

Delay:
- Graphs
- layout strategies as separate SSoT
- shader layer as standalone SSoT

### Step 5 — Use archive selectively
Keep historical material that preserves reasoning, deltas, or traceability.
Do not turn archive into an uncurated dump.

### Step 6 — Repair references and only then deactivate legacy authority paths
Only once each authority-risk file has a new governed home or supersession path should the old structure be considered safely replaced.

---

## 15. Prioritized migration batches

### Batch 1 — Governance scaffold + public/reference normalization

**Goal**  
Create the new docs spine and normalize the public-facing docs into governed roles.

**Primary inputs**
- `README.md`
- `Documentation~/overview.md`
- `Documentation~/noise.md`
- `Documentation~/mesh.md`
- `Documentation~/surfaces.md`
- `Documentation~/shaders.md`
- `Documentation~/graphs.md`

**Expected outputs**
- `Documentation~/README.md`
- `Documentation~/SSoT_INDEX.md`
- `Documentation~/SSoT_CONTRACTS.md`
- `Documentation~/coverage-matrix.md`
- `Documentation~/CURRENT_STATE.md`
- `Documentation~/changelog-ssot.md`
- rewritten root `README.md`

---

### Batch 2 — PCG core + active map pipeline rescue

**Goal**  
Extract real active PCG truth out of WIP and convert it into governed subsystem docs + active roadmap.

**Primary inputs**
- `Documentation~/wip/Islands_PCG_Pipeline_SSoT_v0_1_16.md`
- `Documentation~/wip/Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
- `Documentation~/wip/PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
- `Documentation~/wip/progress reports/Islands_PCG_PhaseF_Progress_Report_F0_F2.md`

**Runtime grounding needed**
- `MapContext2D.cs`
- `MapIds2D.cs`
- `MapInputs.cs`
- `MapTunables2D.cs`
- `MaskFloodFillOps2D.cs`
- `PCGMapVisualization.cs`
- `StageBaseTerrain2DTests.cs`
- `MapPipelineRunner2DGoldenF2Tests.cs`

**Expected outputs**
- `Documentation~/systems/pcg-core-ssot.md`
- `Documentation~/systems/map-pipeline-by-layers-ssot.md`
- `Documentation~/planning/active/PCG_Roadmap.md`
- updates to `CURRENT_STATE.md`, `coverage-matrix.md`, `changelog-ssot.md`, and `supersession-map.md`

---

### Batch 3 — Legacy map-generation triage

**Goal**  
Determine whether legacy tilemap map generation is still an active package concern or only a historical support surface.

**Primary inputs**
- `Documentation~/wip/Map Layers/Map_Generation_SSoT_v0.1.2_2026-01-29.md`
- related runtime code only if still active

**Expected outputs**
- legacy classification decision
- reference/legacy doc or archive-only decision

---

### Batch 4 — Layout strategies verification and staging

**Goal**  
Determine whether layout strategies deserve separate subsystem authority.

**Primary inputs**
- `Documentation~/wip/Islands_PCG_Layout_Strategies_SSoT_v0_1_2.md`
- `CorridorFirstDungeon2D.cs`
- `RoomFirstBspDungeon2D.cs`
- `RoomGridDungeon2D.cs`
- `RoomsCorridorsComposer2D.cs`
- relevant tests

**Expected outputs**
- either staged support under PCG
- or future subsystem SSoT recommendation

---

### Batch 5 — GraphLibrary authority decision

**Goal**  
Determine whether GraphLibrary remains reference/support or is mature enough for promoted subsystem authority.

**Primary inputs**
- `graphs.md`
- `GraphLibrary_Pipeline_Technical_Doc.md`
- representative graph runtime files

**Expected outputs**
- GraphLibrary status decision
- reference cleanup
- future promotion recommendation if warranted

---

### Batch 6 — Noise / Mesh / Surfaces / Shaders hardening

**Goal**  
Convert the public module docs into clean governed reference docs backed by small authoritative subsystem docs where justified.

**Primary inputs**
- representative runtime files for each subsystem
- current module reference docs

**Expected outputs**
- subsystem SSoTs where earned
- clean reference docs
- clearer public package docs

---

## 16. Immediate next move

The most valuable next move is **Batch 2**.

Why:

- it addresses the largest authority-risk zone,
- it rescues real active truth from WIP,
- it clarifies active package direction,
- and it creates the first genuinely useful governed subsystem docs.

---

## 17. Success criteria for this roadmap phase

This first-pass roadmap is successful if it gives a safe and practical path to a future state where:

- no important information is lost,
- package root vs docs root roles are clear,
- implemented vs planned vs historical material is obvious,
- no WIP file silently remains the real authority,
- subsystem authority is earned and bounded,
- reference and research no longer compete with active truth,
- archive remains curated,
- and the package can realistically maintain the new documentation over time.

