# Islands — Batch 2 Roadmap
## PCG Authority Rescue / Map Pipeline by Layers

**Scope:** Resume exactly at Batch 2  
**Migration mode:** preservation-first, salvage-driven, authority-driven  
**Governance model:** v0.4 stack  
**Docs root:** `Documentation~/`

---

## 1) Batch 2 result

Batch 2 closes with a strong authority decision:

- The **active implemented truth** of Islands PCG is the **new grid-first pipeline**.
- Within **Map Pipeline by Layers**, the currently implemented and test-backed slice is **F0–F2**.
- **F3–F6 remain roadmap/planning**, not implemented truth.
- Legacy tilemap map-generation material should be treated as **reference/historical support**, not as active authority for the new PCG runtime.
- The main migration problem is **not lack of documentation**, but that current authority is split across:
  - runtime code,
  - tests,
  - WIP docs with SSoT-like naming,
  - roadmap docs,
  - progress reports.

---

## 2) What Batch 2 was required to rescue

Batch 2 exists to rescue and clarify current documentation authority for:

- PCG core pipeline truth
- Map Pipeline by Layers
- Phase F interpretation
- legacy-vs-active map-generation distinction
- the first governed documentation surfaces for active PCG

This batch does **not** reopen the package-wide first-pass diagnosis.
It does **not** promote every PCG-adjacent subsystem.
It focuses on the **active PCG authority rescue batch**.

---

## 3) Authority diagnosis

### 3.1 Where current truth lives now

Current PCG truth is fragmented across four roles:

1. **Runtime implementation**
   - `MapContext2D`
   - `MapIds2D`
   - `MapInputs`
   - `MapTunables2D`
   - `MapPipelineRunner2D`
   - `Stage_BaseTerrain2D`
   - `MaskFloodFillOps2D`

2. **Runtime verification / gates**
   - `MapPipelineRunner2DTests`
   - `StageBaseTerrain2DTests`
   - `MapPipelineRunner2DGoldenF2Tests`

3. **Mixed WIP documentation**
   - `Documentation~/wip/Islands_PCG_Pipeline_SSoT_v0_1_16.md`

4. **Planning / progress documents**
   - `Documentation~/wip/Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
   - `Documentation~/wip/PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
   - `Documentation~/wip/progress reports/Islands_PCG_PhaseF_Progress_Report_F0_F2.md`

### 3.2 Core authority problem

The main problem is that **WIP still behaves like hidden law**.

The current PCG pipeline WIP doc still mixes:
- subsystem contracts,
- subsystem overview,
- implemented surface description,
- status updates,
- roadmap-adjacent material,
- and historical progress notes.

That means authority is still partially living in a file that:
- is under `wip/`,
- still carries SSoT-style naming,
- and still implicitly acts as a governing document.

### 3.3 What must be rescued first

The first rescue priority is:

1. move **implemented PCG core truth** into governed `systems/`
2. move **implemented Map Pipeline truth** into governed `systems/`
3. move **future Phase F work** into governed `planning/active/`
4. remove hidden authority from WIP docs via explicit supersession / absorption

---

## 4) Truth split

## 4.1 Implemented truth now

### PCG core
Implemented and promotable now:

- grid-first, deterministic, adapters-last pipeline model
- data ownership centered on native-memory grid/field containers
- layered architecture:
  - core
  - grids / fields
  - operators
  - layout
  - adapters / samples
- `MaskGrid2D` as authoritative mask container
- `ScalarField2D` as authoritative scalar field container

### Map Pipeline by Layers
Implemented and promotable now:

#### F0 — Context + contracts
- stable layer/field registries
- `MapInputs`
- `MapTunables2D`
- `MapContext2D`
- `IMapStage2D`
- `MapPipelineRunner2D`

#### F1 — Map lantern
- `PCGMapVisualization`
- layer viewing for mask-based map output
- missing-layer fallback
- dirty regeneration flow

#### F2 — Base terrain
- `Stage_BaseTerrain2D`
- `Height` field
- `Land` mask
- `DeepWater` mask
- deterministic border-connected flood fill via `MaskFloodFillOps2D`

#### Determinism / regression gates
- trivial pipeline determinism test
- trivial pipeline golden
- stage-level F2 determinism test
- stage-level F2 invariant test
- stage-level F2 goldens
- pipeline-level F2 goldens

## 4.2 Active contracts

These are active contracts, not mere planning:

- stable enum ordering for `MapLayerId`
- stable enum ordering for `MapFieldId`
- sanitized seed (`>= 1`)
- deterministic tunable sanitation / range ordering
- no uninitialized layer/field memory leaking into runs
- stable stage execution order = array order
- row-major scan discipline
- deterministic flood-fill queue / seed / neighbor ordering

## 4.3 Roadmap intent

Roadmap-only, not current implementation truth:

- F3 — hills + topology + Islands.Noise jobs bridge
- F4 — shore + shallow water
- F5 — vegetation + fixups (+ optional moisture)
- F6 — paths + stairs + placement outputs
- later morphology / adapters / perf phases

## 4.4 Progress / state reporting

These belong to progress/state reporting, not governing authority:

- “Phase F Progress Report (F0–F2)”
- implementation recap docs
- milestone reports

## 4.5 Historical / legacy

These should not govern the active new PCG runtime:

- legacy tilemap-style map generation material
- legacy island generator mental model as active SSoT

Legacy docs may still remain useful as:
- conceptual reference
- historical support
- comparison baseline
- migration traceability

But they should **not** remain hidden authority for the new pipeline.

## 4.6 Needs runtime verification

Keep conservative:

- any claim about F3+ implementation
- any claim that legacy map generation is still runtime-active for the new PCG package
- any broader layout-strategy promotion beyond this F0–F2 map slice
- any sample-layer behavior that is only present in sample code and not locked in subsystem docs

---

## 5) Promotion decisions

## 5.1 Promote now

### A. `systems/pcg-core-ssot.md`
Promote now.

Why:
- the subsystem boundary is real,
- the contracts are already stable enough,
- the core data model is implemented,
- and it is independent from whether F3–F6 exist yet.

### B. `systems/map-pipeline-by-layers-ssot.md`
Promote now.

But with a strict scope rule:

**It governs only the implemented slice F0–F2.**

Do **not** let future F3–F6 intent bleed into this SSoT.

## 5.2 Do not promote yet

### C. Separate layout-strategies SSoT
Not in Batch 2.

Reason:
- broader layout-strategy authority is outside this rescue slice,
- and evidence is not clean enough here to promote it as its own governed surface.

### D. Phase F as one big authority doc
Do not promote.

Reason:
- Phase F is mixed:
  - F0–F2 are implemented,
  - F3–F6 are planning.
- It must be split.

### E. Samples / visualization layer
Do not promote to subsystem authority.

Role:
- sample/demo/inspection surface
- useful support
- not primary authority

### F. Legacy tilemap map-generation SSoT
Do not treat as active authority for the new runtime direction.

Use as:
- reference-only
- historical-only
- conceptual support
depending on later direct verification of those legacy files.

---

## 6) Governed docs to create now

## 6.1 `Documentation~/systems/pcg-core-ssot.md`

### Purpose
Primary subsystem authority for the new Islands.PCG core.

### Governs
- non-negotiables
- layering
- data model
- core contracts for grids / fields
- adapters-last rule
- deterministic runtime philosophy

### Does not govern
- per-phase planning
- detailed map-stage sequencing
- legacy generators
- sample-only behavior

### Minimum sections
1. Purpose
2. Scope / non-scope
3. Non-negotiables
4. Layering rules
5. Core data contracts
6. Determinism rules
7. Relationship to map-pipeline subsystem
8. Cross-links to roadmap

## 6.2 `Documentation~/systems/map-pipeline-by-layers-ssot.md`

### Purpose
Primary subsystem authority for **implemented** Map Pipeline by Layers behavior.

### Governs
- F0 contracts
- F1 lantern boundary
- F2 base terrain implemented slice
- current layer/field registries
- runner / stage execution model
- determinism gates for current slice

### Does not govern
- F3–F6 roadmap work
- legacy tilemap pipeline
- sample-only convenience behaviors unless explicitly adopted

### Minimum sections
1. Purpose
2. Scope boundary (implemented slice only)
3. Subsystem intent
4. Current layer/field registries
5. F0 contracts
6. F1 current lantern behavior
7. F2 base terrain behavior
8. Determinism rules
9. Test-gated behavior
10. Known limitations
11. Explicit non-governed items

## 6.3 `Documentation~/planning/active/PCG_Roadmap.md`

### Purpose
Planning-only document for future PCG sequencing.

### Governs
- roadmap sequencing
- phase status
- phase exit criteria
- next work after F2
- relationship between implemented truth and future phases

### Does not govern
- implemented runtime behavior
- subsystem contracts

### Minimum sections
1. Rule: planning is not implementation truth
2. Current phase snapshot
3. Phase F status
4. F3–F6 sequencing
5. Later phases
6. Legacy relationship note
7. Explicit links to governing SSoTs

---

## 7) Required updates to governance spine docs

## 7.1 Update now
These should be updated as part of Batch 2:

- `Documentation~/CURRENT_STATE.md`
- `Documentation~/coverage-matrix.md`
- `Documentation~/changelog-ssot.md`
- `Documentation~/supersession-map.md`
- `Documentation~/migration-log.md`

## 7.2 Optional / minimal update
- `Documentation~/SSoT_CONTRACTS.md`

Only update this if the project’s contract index is intended to list promoted cross-subsystem contracts.
Do **not** force a contracts-file change if the subsystem SSoTs are sufficient.

---

## 8) File-by-file migration map

## 8.1 Documentation corpus

### `Documentation~/wip/Islands_PCG_Pipeline_SSoT_v0_1_16.md`
**Action:** absorb + supersede  
**Target:**
- `Documentation~/systems/pcg-core-ssot.md`
- `Documentation~/systems/map-pipeline-by-layers-ssot.md`

**Why:** mixed document; cannot remain hidden authority in WIP.

### `Documentation~/wip/Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
**Action:** move-to-planning + supersede  
**Target:**
- `Documentation~/planning/active/PCG_Roadmap.md`

**Why:** active roadmap, not subsystem truth.

### `Documentation~/wip/PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
**Action:** absorb planning deltas + archive original  
**Target:**
- absorb into `Documentation~/planning/active/PCG_Roadmap.md`
- preserve original under `Documentation~/planning/archive/`

**Why:** useful delta-planning detail, but should not compete with the active roadmap.

### `Documentation~/wip/progress reports/Islands_PCG_PhaseF_Progress_Report_F0_F2.md`
**Action:** absorb + archive  
**Target:**
- implemented deltas to `systems/map-pipeline-by-layers-ssot.md`
- operational snapshot to `CURRENT_STATE.md`
- migration traceability to `migration-log.md`

**Why:** progress reporting, not governing authority.

## 8.2 Runtime / tests corpus

### `Runtime/PCG/Layout/Maps/MapContext2D.cs`
**Action:** keep in place  
**Role:** runtime truth referenced by subsystem docs

### `Runtime/PCG/Layout/Maps/MapIds2D.cs`
**Action:** keep in place  
**Role:** registry truth

### `Runtime/PCG/Layout/Maps/MapInputs.cs`
**Action:** keep in place  
**Role:** input contract truth

### `Runtime/PCG/Layout/Maps/MapTunables2D.cs`
**Action:** keep in place  
**Role:** tunable contract truth

### `Runtime/PCG/Operators/MaskFloodFillOps2D.cs`
**Action:** keep in place  
**Role:** F2 operator truth

### `Runtime/PCG/Samples/PCGMapVisualization.cs`
**Action:** keep only as sample/demo context  
**Role:** inspection surface, not governing authority

### `Runtime/PCG/Tests/EditMode/Layout/Maps/StageBaseTerrain2DTests.cs`
**Action:** keep in place  
**Role:** stage-level implementation gates

### `Runtime/PCG/Tests/EditMode/Layout/Maps/MapPipelineRunner2DGoldenF2Tests.cs`
**Action:** keep in place  
**Role:** pipeline-level implementation gates

### `Runtime/PCG/Grids/MaskGrid2D.cs`
**Action:** keep in place  
**Role:** core runtime truth

### `Runtime/PCG/Grids/MaskGrid2D.Hash.cs`
**Action:** keep in place  
**Role:** hashing / regression gate truth

### `Runtime/PCG/Fields/ScalarField2D.cs`
**Action:** keep in place  
**Role:** core runtime truth

### `Runtime/PCG/Layout/Maps/MapPipelineRunner2D.cs`
**Action:** keep in place  
**Role:** runner truth

### `Runtime/PCG/Layout/Maps/Stages/Stage_BaseTerrain2D.cs`
**Action:** keep in place  
**Role:** F2 stage truth

### `Runtime/PCG/Tests/EditMode/Layout/Maps/MapPipelineRunner2DTests.cs`
**Action:** keep in place  
**Role:** basic runner gate / drift alarm

---

## 9) Supersession plan

## 9.1 Files that need `superseded-by`

### `Documentation~/wip/Islands_PCG_Pipeline_SSoT_v0_1_16.md`
Superseded by:
- `Documentation~/systems/pcg-core-ssot.md`
- `Documentation~/systems/map-pipeline-by-layers-ssot.md`

### `Documentation~/wip/Islands_PCG_Roadmap_Integrated_With_MapLayers_v0.2.4_2026-02-03.md`
Superseded by:
- `Documentation~/planning/active/PCG_Roadmap.md`

## 9.2 Files that need `absorbed-into`

### `Documentation~/wip/PhaseF_Planning_Report_MapPipeline_F3_F6_NoiseJobs_2026-02-03_v2.md`
Absorbed into:
- `Documentation~/planning/active/PCG_Roadmap.md`

### `Documentation~/wip/progress reports/Islands_PCG_PhaseF_Progress_Report_F0_F2.md`
Absorbed into:
- `Documentation~/systems/map-pipeline-by-layers-ssot.md`
- `Documentation~/CURRENT_STATE.md`
- `Documentation~/migration-log.md`

## 9.3 Files that should stop implying authority
Any file in `Documentation~/wip/` whose name still includes or implies:
- `SSoT`
- “design bible” in governing tone
- authoritative phase truth
- implicit current-system law

must either:
- be promoted into governed docs,
- be explicitly superseded,
- or be archived with role clarified.

---

## 10) Draft-ready content starter blocks

## 10.1 Draft starter — `systems/pcg-core-ssot.md`

```md
# Islands.PCG — PCG Core SSoT

Status: Active
Authority: Primary subsystem authority for the new Islands.PCG core
Docs root: Documentation~/

## Purpose
This document governs the active contracts of the new grid-first Islands.PCG core.

## Governs
- non-negotiables
- subsystem layering
- deterministic grid/field data model
- adapters-last rule

## Does not govern
- roadmap sequencing
- detailed Map Pipeline stage planning
- legacy tilemap generators

## Non-negotiables
- same inputs + same seed => same outputs
- no UnityEngine.Random in core runtime
- dense grids / fields as authoritative state
- adapters are outputs, never core dependencies
- deterministic regression gates required

## Layering
math -> grid -> ops -> layout -> adapters/samples

## Core data contracts
### GridDomain2D
- immutable domain
- row-major indexing

### MaskGrid2D
- authoritative 0/1 mask container
- owns native memory
- deterministic tail-bit discipline
- supports snapshot hashing

### ScalarField2D
- authoritative scalar field container
- owns native memory
- mutable struct: avoid accidental copies

## Cross-links
- Implemented map subsystem truth: `systems/map-pipeline-by-layers-ssot.md`
- Future sequencing: `planning/active/PCG_Roadmap.md`
```

## 10.2 Draft starter — `systems/map-pipeline-by-layers-ssot.md`

```md
# Islands.PCG — Map Pipeline by Layers SSoT

Status: Active (implemented slice only)
Authority: Primary subsystem authority for implemented Map Pipeline by Layers behavior
Docs root: Documentation~/

## Purpose
This document governs the implemented and test-backed truth of Map Pipeline by Layers.

## Scope boundary
This SSoT covers only:
- F0 Context + contracts
- F1 current map lantern
- F2 base terrain

F3+ belongs to planning.

## Subsystem intent
A general deterministic map-generation pipeline built on layer stacks inside `MapContext2D`, using deterministic stages and headless outputs.

## Current registries
### Layers
- Land
- DeepWater
- ShallowWater
- HillsL1
- HillsL2
- Paths
- Stairs
- Vegetation
- Walkable

### Fields
- Height
- Moisture

## F0 — contracts
- `MapInputs`
- `MapTunables2D`
- `MapContext2D`
- `IMapStage2D`
- `MapPipelineRunner2D`

## F1 — lantern
- `PCGMapVisualization`
- layer selection
- missing-layer fallback
- regeneration on dirty changes

## F2 — base terrain
- `Stage_BaseTerrain2D`
- writes `Height`
- thresholds to `Land`
- computes `DeepWater` via deterministic border-connected flood fill

## Determinism rules
- stable registry order
- seed sanitation
- no uninitialized layer/field memory
- stable stage order
- row-major scans
- deterministic flood-fill behavior

## Test-gated behavior
- trivial pipeline determinism
- trivial pipeline golden
- stage-level F2 determinism
- stage-level F2 invariants
- stage-level F2 goldens
- pipeline-level F2 goldens

## Known limitations
- lantern is still mask-first
- F3+ not governed here
- sample-only tuning helpers do not define subsystem authority
```

## 10.3 Draft starter — `planning/active/PCG_Roadmap.md`

```md
# Islands.PCG — Active Roadmap

Status: Active planning
Authority: Planning only

## Rule
This document is not implementation authority.
Implemented truth lives in subsystem SSoTs.

## Current snapshot
- Phase A: done
- Phase B: done
- Phase C: done
- Phase D: done
- Phase E: in progress elsewhere
- Phase F: in progress
  - F0: done
  - F1: done
  - F2: done
  - F3: next
- Phase G+: later

## Phase F
### Done
- F0 context + contracts
- F1 map lantern
- F2 base terrain

### Next
#### F3 — Hills + topology
- topology layers
- `MaskTopologyOps2D`
- `Stage_Hills2D`
- Islands.Noise jobs bridge
- F3 goldens
- lantern update

#### F4 — Shore + ShallowWater
#### F5 — Vegetation + fixups
#### F6 — Paths / stairs / placement

## Legacy relationship
Legacy map-generation docs are conceptual reference only for the new pipeline.
The active direction is masks / fields + adapters-last + deterministic headless stages.
```

---

## 11) Recommended Batch 2 execution order

### Step 1
Create:
- `Documentation~/systems/pcg-core-ssot.md`
- `Documentation~/systems/map-pipeline-by-layers-ssot.md`
- `Documentation~/planning/active/PCG_Roadmap.md`

### Step 2
Populate them by salvage:
- extract atomic claims from WIP docs
- move only missing deltas
- do not copy whole legacy docs blindly

### Step 3
Update governance spine:
- `CURRENT_STATE.md`
- `coverage-matrix.md`
- `changelog-ssot.md`
- `supersession-map.md`
- `migration-log.md`

### Step 4
Add explicit headers to old docs:
- superseded-by
- absorbed-into
- archive/reference role clarification

### Step 5
Leave runtime code/tests in place and cite them from governed docs.
Do not create a second authority layer inside code folders.

---

## 12) Batch 2 done criteria

Batch 2 is done when all of the following are true:

1. Active PCG truth no longer lives primarily in `Documentation~/wip/`
2. F0–F2 are governed by subsystem SSoTs
3. F3–F6 are governed only by planning docs
4. WIP docs no longer imply hidden authority
5. supersession / absorption is explicit
6. current state + migration traceability are updated
7. legacy tilemap material is no longer confused with active runtime truth

---

## 13) Final decision summary

### Implemented now
- PCG core contracts
- Map Pipeline by Layers F0–F2
- runner + context + deterministic base terrain + goldens

### Planned only
- F3–F6 and beyond

### Historical / reference
- legacy tilemap map-generation authority for the old system

### Immediate migration move
- promote core + implemented map slice
- move roadmap to governed planning
- strip hidden authority out of WIP
